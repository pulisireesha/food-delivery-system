from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)


def get_db():
    conn = sqlite3.connect("food.db")
    conn.row_factory = sqlite3.Row
    return conn


def create_database():
    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS foods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer TEXT NOT NULL,
            food TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            total REAL NOT NULL
        )
    """)

    count = conn.execute(
        "SELECT COUNT(*) FROM foods"
    ).fetchone()[0]

    if count == 0:
        foods = [
            ("Pizza", 250),
            ("Burger", 150),
            ("Biryani", 200),
            ("Fried Rice", 180),
            ("Dosa", 80),
            ("Chicken Noodles", 170)
        ]

        conn.executemany(
            "INSERT INTO foods (name, price) VALUES (?, ?)",
            foods
        )

    conn.commit()
    conn.close()


@app.route("/")
def home():
    conn = get_db()
    foods = conn.execute("SELECT * FROM foods").fetchall()
    conn.close()

    return render_template("index.html", foods=foods)


@app.route("/order", methods=["POST"])
def order():
    customer = request.form["customer"]
    food_id = request.form["food"]
    quantity = int(request.form["quantity"])

    conn = get_db()

    food = conn.execute(
        "SELECT * FROM foods WHERE id = ?",
        (food_id,)
    ).fetchone()

    total = food["price"] * quantity

    conn.execute("""
        INSERT INTO orders
        (customer, food, quantity, total)
        VALUES (?, ?, ?, ?)
    """, (customer, food["name"], quantity, total))

    conn.commit()
    conn.close()

    return redirect("/success")


@app.route("/success")
def success():
    return """
    <h1>✅ Order Placed Successfully!</h1>
    <p>Your food order has been received.</p>
    <a href="/">Back to Menu</a>
    """


@app.route("/orders")
def orders():
    conn = get_db()

    orders = conn.execute(
        "SELECT * FROM orders ORDER BY id DESC"
    ).fetchall()

    conn.close()

    return render_template("orders.html", orders=orders)


if __name__ == "__main__":
    create_database()

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )